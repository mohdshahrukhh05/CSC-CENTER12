import { GoogleGenAI } from "@google/genai";

// Initialize lazily to prevent top-level errors if env vars aren't immediately available.
let ai: GoogleGenAI | null = null;

function getAi() {
  if (!ai) {
    // FIX: Per coding guidelines, API key is assumed to be present in environment variables.
    // Lazy initialization moves potential errors into the try/catch block of the calling function.
    ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
  }
  return ai;
}

export const getGeminiResponse = async (prompt: string): Promise<string> => {
  try {
    const genAI = getAi();
    // FIX: Refactored to use systemInstruction for context and pass the user prompt directly as contents, which is a better practice.
    const response = await genAI.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: `You are a helpful assistant for a Common Service Centre named "Mohammad Faizan Jan Seva Kendra". Answer questions related to their services, but do not answer questions outside of this scope.`,
      },
    });
    return response.text;
  } catch (error) {
    console.error("Error fetching from Gemini API:", error);
    return "Sorry, I'm having trouble connecting to the AI service right now.";
  }
};

export const generateImage = async (prompt: string): Promise<string | null> => {
  try {
    const genAI = getAi();
    const response = await genAI.models.generateImages({
      model: 'imagen-4.0-generate-001',
      prompt: prompt,
      config: {
        numberOfImages: 1,
        outputMimeType: 'image/jpeg',
        aspectRatio: '1:1',
      },
    });
    
    if (response.generatedImages && response.generatedImages.length > 0) {
      const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
      return `data:image/jpeg;base64,${base64ImageBytes}`;
    }
    return null;

  } catch (error) {
    console.error("Error generating image with Imagen API:", error);
    return null;
  }
};