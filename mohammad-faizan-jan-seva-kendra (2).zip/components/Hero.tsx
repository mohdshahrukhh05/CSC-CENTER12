import React from 'react';
import { TranslationContent } from '../types';
import Section from './Section';

interface HeroProps {
  translations: TranslationContent['hero'];
  onNavigate: (sectionId: string) => void;
}

const Hero: React.FC<HeroProps> = ({ translations, onNavigate }) => {
  return (
    <Section id="home" className="bg-cover bg-center text-white" style={{backgroundImage: "url('https://picsum.photos/1920/1080?grayscale&blur=2')"}}>
      <div className="bg-black bg-opacity-50 py-20 md:py-32 text-center">
        <h2 className="text-4xl md:text-6xl font-extrabold">{translations.title}</h2>
        <p className="mt-4 text-lg md:text-xl max-w-3xl mx-auto">{translations.subtitle}</p>
        <button onClick={() => onNavigate('request-service')} className="mt-8 bg-blue-600 text-white px-8 py-3 rounded-full text-lg font-semibold hover:bg-blue-700 transition-transform transform hover:scale-105">
          {translations.cta}
        </button>
      </div>
    </Section>
  );
};

export default Hero;
