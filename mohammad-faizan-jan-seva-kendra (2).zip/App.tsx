import React, { useState } from 'react';
import { Language } from './types';
import { translations } from './constants';
import Header from './components/Header';
import Hero from './components/Hero';
import Services from './components/Services';
import Team from './components/Team';
import Contact from './components/Contact';
import ServiceRequest from './components/ServiceRequest';
import Chatbot from './components/Chatbot';
import ImageGeneration from './components/ImageGeneration';

const App: React.FC = () => {
  const [language, setLanguage] = useState<Language>(Language.EN);
  const t = translations[language];

  const handleNavigate = (sectionId: string) => {
    const section = document.getElementById(sectionId);
    section?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="bg-gray-100 text-gray-800 font-sans">
      <Header language={language} setLanguage={setLanguage} translations={t.nav} onNavigate={handleNavigate} />
      
      <main>
        <Hero translations={t.hero} onNavigate={handleNavigate} />
        <Services translations={t.services} />
        <Team translations={t.team} />
        <ImageGeneration translations={t.imageGeneration} />

        <ServiceRequest 
          nav={t.nav}
          services={t.services}
          serviceRequest={t.serviceRequest}
          statusCheck={t.statusCheck}
        />

        <Contact translations={t.contact} />
      </main>

      <Chatbot translations={t.chatbot} />

      <footer className="bg-gray-800 text-white py-6">
        <div className="container mx-auto px-4 text-center">
            <p>&copy; {new Date().getFullYear()} Mohammad Faizan Jan Seva Kendra. All Rights Reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default App;