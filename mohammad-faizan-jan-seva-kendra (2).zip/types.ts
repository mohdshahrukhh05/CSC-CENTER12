export enum Language {
  EN = 'en',
  HI = 'hi',
}

export interface ServiceItem {
  title: string;
  description: string;
  price?: string;
}

export interface TeamMember {
  name: string;
  role: string;
}

export interface HeaderTranslations {
  home: string;
  services: string;
  team: string;
  contact: string;
  imageGeneration: string;
  requestService: string;
  checkStatus: string;
}

export interface TranslationContent {
  nav: HeaderTranslations;
  hero: {
    title:string;
    subtitle: string;
    cta: string;
  };
  services: {
    title: string;
    items: ServiceItem[];
  };
  team: {
    title: string;
    members: TeamMember[];
  };
  contact: {
    title: string;
    address: string;
    email: string;
    phone: string;
    whatsapp: string;
    instagram: string;
    socials: string;
  };
  imageGeneration: {
    title: string;
    promptLabel: string;
    promptPlaceholder: string;
    buttonText: string;
    generatingText: string;
  },
  serviceRequest: {
    title: string;
    nameLabel: string;
    phoneLabel: string;
    serviceLabel: string;
    messageLabel: string;
    submitButton: string;
    formDescription: string;
    thankYouTitle: string;
    thankYouMessage: (requestId: string) => string;
    thankYouNote: string;
    newRequestButton: string;
  };
  statusCheck: {
    title: string;
    requestIdLabel: string;
    checkButton: string;
    statusResult: (status: string) => string;
    notFound: string;
    noId: string;
  };
  chatbot: {
    title: string;
    placeholder: string;
  };
}

export type Translations = {
  [key in Language]: TranslationContent;
};

export interface ServiceRequest {
  id: string;
  name: string;
  phone: string;
  service: string;
  message: string;
  status: 'Pending' | 'In Progress' | 'Completed';
}